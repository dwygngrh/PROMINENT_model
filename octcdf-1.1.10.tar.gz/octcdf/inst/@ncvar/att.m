function a = att(self)
 a = ncatt(self);
end
