function d = dim(self)
  d = ncdim(self);
end
