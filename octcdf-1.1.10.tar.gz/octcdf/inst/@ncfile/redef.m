function redef(self)
 ncredef(self)
end
