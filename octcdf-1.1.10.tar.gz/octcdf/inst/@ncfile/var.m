function v = var(self)
 v = ncvar(self);
end
