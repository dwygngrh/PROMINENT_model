function n = name(self)
 n = ncname(self);
end
