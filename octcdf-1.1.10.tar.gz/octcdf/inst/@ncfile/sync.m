function sync(self)
 ncsync(self)
end
