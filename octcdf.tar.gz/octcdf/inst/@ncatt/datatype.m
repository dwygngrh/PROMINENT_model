function dt = datatype(self)
 dt = ncdatatype(self);
end
