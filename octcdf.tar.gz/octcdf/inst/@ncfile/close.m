function close (self)
 ncclose (self)
end