function endef(self)
 ncendef(self)
end
