% depreciated: use isrecdim instead
function isr = isrecord(self)
 isr = ncisrecord(self);
end
