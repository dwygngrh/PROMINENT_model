function nv = autoscale(self,varargin)
  nv = ncautoscale(self,varargin{:});
end
