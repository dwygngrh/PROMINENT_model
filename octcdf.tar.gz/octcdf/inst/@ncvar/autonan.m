function nv = autonan(self,varargin)
 nv = ncautonan(self,varargin{:});
end
